import sys
sys.stdin = open('1945_input.txt')

T = int(input())

for tc in range(1, T+1):
    N = int(input())

    while N == 1:
        if N // 2
