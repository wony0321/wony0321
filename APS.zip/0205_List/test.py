import sys

# a = ''
# b = 'h'
#
# print(sys.getsizeof(a))
# print(sys.getsizeof(b))

# s1 = list(input())
# s2 = input()
# s1[0] = 'd'
# print(s1)
# print(s2[0])
# s2[0] = 'a'

# s1 = 'abc'
# s2 = 'abc'
# # s1과 s2는 같은 내용을 가리킬 것
# print(s1 == s2)
# print(s1 is s2)
#
# s3 = s1[:2] + 'c'
# # but s3는 다른 내용을 가리킬 것
# print(s3)
# print(s1 == s3)
# print(s1 is s3)

# print(ord('A'))
# print(ord(' '))
# print(ord('0'))
# print(ord('9'))
# print(ord('9')-ord('0'))
# # 출력값: 9
# # 아스키 코드의 차이로 실제 값을 추출할 수 있음
#
# print(chr(57))
# print(chr(3+ord('0')))

# def itoa(a):
#     s = ''
#     while a > 0:
#         s = chr(a % 10 + ord('0')) + s
#         a //= 10
#     return s
#
# ans = itoa(123)
# print(type(ans))
# print(ans)


