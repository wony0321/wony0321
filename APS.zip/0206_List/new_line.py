import sys
sys.stdin = open('new_line.txt')

print('a\nb')
print('a')  # 콘솔 a 찍어
print()
print('b')  # 콘솔 b 찍어